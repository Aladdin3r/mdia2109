# Assessment 4

## Created by
- Aladdin
- A01386700

## Description
- This application is a basic about BCIT website with distinct stylization and an animation. Most importantly, it goes through unit tests to make sure it is functioning accordingly.

## Desktop screen size
- 1st screen (monitor): 1920 x 1080
- 2nd screen (laptop): 1440 x 900