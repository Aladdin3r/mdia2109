# Assessment 3

## Created by:
- Aladdin
- A01386700
## Description
- This application filters through different textbooks by 3 different filters:
    - book title
    - book edition in ascending order
    - book edition in descending order
- It is responsive and features a interactive side navigation bar.